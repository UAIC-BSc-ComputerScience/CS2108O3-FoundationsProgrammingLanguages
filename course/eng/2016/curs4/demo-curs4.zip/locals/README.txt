Copy the content of imp-locals-k.k (or imp-locals-stack.k)
into a file called imp.k. Then, kompile the imp.k file.
