#include <stdio.h>
#include <stdlib.h>

int main() {

  int n, sum;

  // read
  printf("n = ");
  scanf("%d", &n);
  
  sum = 0;
  if (n < 0) {
    printf("Cannot compute sum up to a negative number!\n");
    exit(1);
  } else  {
    while (n > 0) {
      sum = sum + n;
      n = n - 1;
    }
  }
  printf("Sum = %d\n", sum);  
  return 0;
}
