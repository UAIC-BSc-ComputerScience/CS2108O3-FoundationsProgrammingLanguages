man(john).
man(mark).
man(dan).

father(john, mark).
father(mark, dan).

grandfather(X, Y) :- man(X), father(X, Z), father(Z, Y).
