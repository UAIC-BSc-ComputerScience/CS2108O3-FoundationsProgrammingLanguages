public class Driver extends Person {

    private boolean isDriving;

    public Driver(String name) {
	super(name);
	isDriving = false;
    }

    public boolean getStatus() {
	return isDriving;
    }

    public String getName() {
	return "DRIVER: " + super.getName();
    }

    public String getName(String intro) {
	return intro + super.getName();
    }
    
    public static void main(String[] args) {

	Driver driver = new Driver("mark");

	System.out.println(driver.getName());
	System.out.println(driver.getName("Driver: "));
	System.out.println(driver.getStatus());
	
    }
}
