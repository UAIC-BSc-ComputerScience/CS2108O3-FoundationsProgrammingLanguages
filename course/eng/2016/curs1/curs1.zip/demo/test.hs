
mysum :: Integer -> Integer
mysum n = if (n < 0 )
          then 0
          else n + mysum (n - 1)

